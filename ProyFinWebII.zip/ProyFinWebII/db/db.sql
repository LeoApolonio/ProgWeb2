DROP DATABASE IF EXISTS node_crud;
CREATE DATABASE node_crud;
USE node_crud;

CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    carrera VARCHAR(100) NOT NULL,
    semestre INT NOT NULL,
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO users (name, email, password, carrera, semestre)
VALUES
('Carlos Herrera', 'carlos@aragon.unam', '12345', 'Ingeniería en Computación', 3),
('María López',   'maria@aragon.unam',  'pass1', 'Arquitectura', 5),
('Juan Pérez',    'juan@aragon.unam',   'abcde', 'Contaduría', 2),
('Sofía Ramos',   'sofia@aragon.unam',  'sofia1','Psicología', 1),
('Luis Ortega',   'luis@aragon.unam',   'elui','Derecho', 4);
